# Manutenção Industrial LD — V2

Aplicativo local/offline para cadastro de equipamentos, ordens de serviço, agenda preventiva, fotos antes/depois, relatório para impressão/salvamento em PDF e backup JSON.

## Atualização do repositório pelo celular
1. Baixe e extraia este ZIP.
2. No repositório GitHub `ManutencaoIndustrialLD`, abra `Add file` → `Upload files`.
3. Envie/substitua os arquivos da pasta `www` e os arquivos `package.json` e `capacitor.config.json` na raiz. Se enviar o ZIP completo, extraia os arquivos antes — não envie somente o ZIP esperando que o GitHub o extraia.
4. Confirme em `Commit changes`. O workflow Build Manutenção Industrial LD APK deve iniciar.
5. Quando terminar, abra Actions → execução concluída → Artifacts e baixe `manutencao-industrial-ld-apk`.

## Observações
- Os dados ficam no armazenamento local do aplicativo e não sincronizam entre aparelhos.
- O relatório abre a janela de impressão do Android; escolha **Salvar como PDF** para criar e compartilhar o PDF.
- Faça backups JSON regularmente. Fotos são comprimidas antes de serem salvas.
